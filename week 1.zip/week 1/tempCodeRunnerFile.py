 # if(i < len(posArray)) :
    #        newArray.append(posArray[i])
    # if(j < len(negArray)) :
    #     newArray.append(negArray[j])   