# print ("Hi Areeba to Data Structure and Algorithms Course")
# print("hello world")
# a=6
# print("value of a is " ,a)
# a = input('enter value')
# b = int(a)
# print("a is ", b)
# arr = [9,8,7,6]
# array = [[765,65],[0,9,8]]
# sum = arr+array
# print(sum)
# array = [0 * 10]
# print (array)
# array1 = [[0 for x in range(4)] for y in range(3)]
# print(array1)

# import numpy as np;
# arr1 = np.zeros(5)
# print (arr1)
# arr2 = np.zeros((3,4))
# print (arr2)


# import random;
# arr=[]
# min = 20
# max = 70
# n = 5
# for i in range(0,n):
#  num = random.randint(min,max)
#  arr.append(num)
# arr.sort() 
# print(arr)

# str = ['u', 'e', 't']
# for x in range (len(str)):
#     print(str[x])
# print(arr[1:5:2])
# array.reverse()
# print(array)

# array = [9,8,7,6,5,4,3,2,1,0]
# for i in range (len(array)-1,-1,-1):
#     print(array[i])
# arr = [1,2,3,4,5] 
# arr [2:]
# print(arr [:-3])

# Open the file in read mode
# given_file = open('C:/Users/Rashid ch/OneDrive/Documents/DSA PYTHON/test.txt', mode='r')

# lines = given_file.read()
# given_file.close()
# data=lines.split() 
# array =[]
# for i in data:
#     b = int(i)
#     array.append(b) 

# print(array) 


# arr = ['Hello world', 'UET']
# f =  open('C:/Users/Rashid ch/OneDrive/Documents/DSA PYTHON/test.txt', mode='a')
# for i in arr:
#     f.write(i + "/n")

# def display(arr):
#  for i in arr:
#     print(i)
#  print(arr) 
    
   

 
# array = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# display(array)



# sum = 0 
# for i in range (12):
#  sum += i
# print(sum)


# def sum(n):
#    if ( n==0):
#        return n
#    else :
#       return n+sum(n-1)  
   
# print (sum(11))


# arr = [1,2,3,4,5,6,7,8,9,10]
# for i in arr:
#  print(i)
 
# def printArray (arr, start, end):
#  if start == end:
#        print(arr[start])
#  else:
#       print(arr[start])
#       printArray (arr, start+1, end)
# arr = [4,5,6,7,8,9]
# printArray (arr, 0, len(arr)-1)



# num = 2
# power = 5
# result = 1
# for i in range(power): #     2 ----> 0,1
#  result = result * num
# print(result)


# def pow(num,power):
#    if(power == 1) :
#     return num
#    else:   
#      return num* pow(num,power-1)


# num = 2
# power = 4 

# print(pow(num,power))

# def rec_factorial(num):
#   if (num < 0):
#      return -1
#   elif(num == 0 or num == 1):
#       return 1
#   else :
#    return   num * rec_factorial(num-1)
      
   
   
    


# num = int(input("enter a number"))

# print(rec_factorial(num))
